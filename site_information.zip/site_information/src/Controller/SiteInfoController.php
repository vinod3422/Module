<?php


namespace Drupal\site_information\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\node\Entity\Node;
use Symfony\Component\HttpFoundation\JsonResponse;


class SiteInfoController extends ControllerBase {


	public function PageJson($api_url, $node_id) {


		$api_key = \Drupal::config('system.site')->get('siteapikey');
		$node_load = \Drupal::entityManager()->getStorage('node')->load($node_id);

		if ($api_url == $api_key && $node_load) {
			$node_type = $node_load->get('type')->getString();
			if ($node_type == 'page') {
				$json_array['data'][] = array(
                    'type' => $node_load->get('type')->getString(),
                    'id' => $node_load->get('nid')->getString(),
                    'attributes' => array(
                      'title' =>  $node_load->get('title')->getString(),
                      'content' => $node_load->get('body')->getString(),
                    ),
                );
			    }
		    }else{
				throw new \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException();
			}

		return new JsonResponse($json_array);
	}
	
	
}