<?php

namespace Drupal\site_information\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\system\Form\SiteInformationForm;


class SiteInfoForm extends SiteInformationForm {
 
   /**
   * {@inheritdoc}
   */
    public function buildForm(array $form, FormStateInterface $form_state) {
      $form =  parent::buildForm($form, $form_state);
      $configuation = $this->config('system.site');
    
    $form['api_key']['siteapikey'] = [
      '#type' => 'textfield',
      '#title' => t('Site API Key'),
      '#default_value' => $configuation->get('siteapikey') ?: 'No API Key yet',
    ];
    
    $form['actions']['submit']['#value'] = t('Update Configuration');
    
    return $form;
  }
  
    public function submitForm(array &$form, FormStateInterface $form_state) {
       $entity = $this->config('system.site');
       $field_value = $form_state->getValue('siteapikey');
       $entity->set('siteapikey', $field_value)->save();
      Drupal_set_message('Site API Key has been saved with '.$field_value.' value');
       parent::submitForm($form, $form_state);
    }
}